<!-- Guido Gentile custom banner -->
<div align="center">
  <picture>
    <source media="(prefers-color-scheme: dark)" srcset="assets/banner-dark.v9.svg">
    <source media="(prefers-color-scheme: light)" srcset="assets/banner-light.v9.svg">
    <img src="assets/banner-light.v9.svg" width="960" alt="Guido Gentile developer profile banner">
  </picture>
</div>

<br>

## `$ whoami`

<p align="center">
  <img src="assets/whoami-citypop.svg" width="960" alt="Guido Gentile profile terminal">
</p>
